import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./Landing.css";

/* ============================================================
   REACT BITS — GRAVITY (Anti-Gravity Particle Field)
   Norse runes float freely, repel from cursor, drift with
   simulated zero-gravity physics using Canvas
============================================================ */
const RUNES = ["ᚠ","ᚢ","ᚦ","ᚨ","ᚱ","ᚲ","ᚷ","ᚹ","ᚺ","ᚾ","ᛁ","ᛃ","ᛇ","ᛈ","ᛉ","ᛊ","ᛏ","ᛒ","ᛖ","ᛗ","ᛚ","ᛜ","ᛞ","ᛟ"];

const GravityField = ({ count = 30, repelRadius = 150, repelForce = 0.5 }) => {
  const canvasRef = useRef(null);
  const mouseRef = useRef({ x: -9999, y: -9999 });
  const particlesRef = useRef([]);
  const rafRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let W = (canvas.width = window.innerWidth);
    let H = (canvas.height = window.innerHeight);

    particlesRef.current = Array.from({ length: count }, (_, i) => ({
      id: i,
      x: Math.random() * W,
      y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      bvx: (Math.random() - 0.5) * 0.3,
      bvy: (Math.random() - 0.5) * 0.3,
      rune: RUNES[i % RUNES.length],
      size: Math.random() * 16 + 10,
      opacity: Math.random() * 0.15 + 0.04,
      phase: Math.random() * Math.PI * 2,
      rot: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.008,
      bobAmp: Math.random() * 0.12 + 0.04,
      bobFreq: Math.random() * 0.007 + 0.002,
      colorType: i % 3, // 0=gold, 1=green, 2=gold-dim
    }));

    const onResize = () => { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; };
    const onMouse = (e) => { mouseRef.current = { x: e.clientX, y: e.clientY }; };
    const onLeave = () => { mouseRef.current = { x: -9999, y: -9999 }; };

    window.addEventListener("resize", onResize);
    window.addEventListener("mousemove", onMouse);
    window.addEventListener("mouseleave", onLeave);

    let tick = 0;

    const draw = () => {
      tick++;
      ctx.clearRect(0, 0, W, H);
      const mouse = mouseRef.current;

      particlesRef.current.forEach((p) => {
        // Anti-gravity sinusoidal bob
        p.vy += Math.sin(tick * p.bobFreq + p.phase) * p.bobAmp * 0.008;

        // Cursor repulsion
        const dx = p.x - mouse.x;
        const dy = p.y - mouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < repelRadius && dist > 1) {
          const strength = ((repelRadius - dist) / repelRadius) * repelForce;
          p.vx += (dx / dist) * strength;
          p.vy += (dy / dist) * strength;
        }

        // Drift toward base velocity
        p.vx += (p.bvx - p.vx) * 0.015;
        p.vy += (p.bvy - p.vy) * 0.015;

        // Damping
        p.vx *= 0.96;
        p.vy *= 0.96;

        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.rotSpeed;

        // Wrap
        const m = 70;
        if (p.x < -m) p.x = W + m;
        if (p.x > W + m) p.x = -m;
        if (p.y < -m) p.y = H + m;
        if (p.y > H + m) p.y = -m;

        // Breathe
        const breathe = Math.sin(tick * 0.01 + p.phase) * 0.03;
        const alpha = Math.max(0, p.opacity + breathe);

        // Color
        const colors = ["#c9a84c", "#4a8c5c", "#7a5c1e"];
        const color = colors[p.colorType];

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.globalAlpha = alpha;
        ctx.fillStyle = color;
        ctx.font = `${p.size}px serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(p.rune, 0, 0);

        // Glow when near cursor
        if (dist < repelRadius * 0.5 && dist > 1) {
          const glow = (1 - dist / (repelRadius * 0.5)) * 0.35;
          ctx.globalAlpha = glow;
          ctx.fillStyle = "#e8c96a";
          ctx.fillText(p.rune, 0, 0);
        }

        ctx.restore();
      });

      rafRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("mousemove", onMouse);
      window.removeEventListener("mouseleave", onLeave);
    };
  }, [count, repelRadius, repelForce]);

  return <canvas ref={canvasRef} className="gravity-canvas" />;
};

/* ============================================================
   REACT BITS — SMOOTH MAGNETIC CURSOR (lerped)
============================================================ */
const MagneticCursor = () => {
  const outerRef = useRef(null);
  const dotRef = useRef(null);
  const pos = useRef({ x: 0, y: 0 });
  const target = useRef({ x: 0, y: 0 });
  const raf = useRef(null);

  useEffect(() => {
    const onMove = (e) => { target.current = { x: e.clientX, y: e.clientY }; };
    window.addEventListener("mousemove", onMove);

    const lerp = (a, b, t) => a + (b - a) * t;
    const tick = () => {
      pos.current.x = lerp(pos.current.x, target.current.x, 0.1);
      pos.current.y = lerp(pos.current.y, target.current.y, 0.1);
      if (outerRef.current)
        outerRef.current.style.transform = `translate(${pos.current.x - 22}px, ${pos.current.y - 22}px)`;
      if (dotRef.current)
        dotRef.current.style.transform = `translate(${target.current.x - 4}px, ${target.current.y - 4}px)`;
      raf.current = requestAnimationFrame(tick);
    };
    tick();
    return () => { window.removeEventListener("mousemove", onMove); cancelAnimationFrame(raf.current); };
  }, []);

  return (
    <>
      <div ref={outerRef} className="cursor-outer" />
      <div ref={dotRef} className="cursor-inner-dot" />
    </>
  );
};

/* ============================================================
   REACT BITS — TYPEWRITER
============================================================ */
const Typewriter = ({ words, speed = 88 }) => {
  const [display, setDisplay] = useState("");
  const [wi, setWi] = useState(0);
  const [ci, setCi] = useState(0);
  const [del, setDel] = useState(false);

  useEffect(() => {
    const cur = words[wi];
    let t;
    if (!del && ci <= cur.length) {
      t = setTimeout(() => { setDisplay(cur.slice(0, ci)); setCi(c => c + 1); }, speed);
    } else if (!del && ci > cur.length) {
      t = setTimeout(() => setDel(true), 1900);
    } else if (del && ci > 0) {
      t = setTimeout(() => { setDisplay(cur.slice(0, ci - 1)); setCi(c => c - 1); }, speed / 2.5);
    } else if (del && ci === 0) {
      setDel(false); setWi(w => (w + 1) % words.length);
    }
    return () => clearTimeout(t);
  }, [ci, del, wi, words, speed]);

  return <span className="typewriter-text">{display}<span className="tw-caret" /></span>;
};

/* ============================================================
   REACT BITS — COUNT UP
============================================================ */
const CountUp = ({ end, suffix = "" }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        let v = 0;
        const step = end / 65;
        const t = setInterval(() => {
          v += step;
          if (v >= end) { setCount(end); clearInterval(t); }
          else setCount(Math.floor(v));
        }, 18);
        obs.disconnect();
      }
    }, { threshold: 0.5 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [end]);
  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>;
};

/* ============================================================
   REACT BITS — SCROLL REVEAL
============================================================ */
const Reveal = ({ children, delay = 0, from = "bottom" }) => {
  const ref = useRef(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); obs.disconnect(); } }, { threshold: 0.08 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal reveal-${from} ${on ? "reveal-on" : ""}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
};

/* ============================================================
   REACT BITS — GLITCH TITLE
============================================================ */
const GlitchTitle = ({ text }) => (
  <span className="glitch" data-text={text} aria-label={text}>{text}</span>
);

/* ============================================================
   DATA
============================================================ */
const products = [
  { id: 1, name: "Norse King Jacket", category: "Clothing",    price: 3499, originalPrice: 4999, badge: "BESTSELLER", emoji: "🧥", glow: "#1a4a2a" },
  { id: 2, name: "Valhalla Polo Tee",  category: "Clothing",    price: 999,  originalPrice: 1499, badge: "NEW",        emoji: "👕", glow: "#0e2a18" },
  { id: 3, name: "Odin Runner Pro",    category: "Footwear",    price: 4299, originalPrice: 5999, badge: "HOT",        emoji: "👟", glow: "#0a3a1a" },
  { id: 4, name: "Mjolnir Chelsea",    category: "Footwear",    price: 5999, originalPrice: 7499, badge: "LIMITED",    emoji: "🥾", glow: "#1a3010" },
  { id: 5, name: "Gold Serpent Watch", category: "Accessories", price: 7499, originalPrice: 9999, badge: "PREMIUM",   emoji: "⌚", glow: "#2a1a08" },
  { id: 6, name: "Rune Leather Belt",  category: "Accessories", price: 1299, originalPrice: 1799, badge: "NEW",        emoji: "👔", glow: "#2a200a" },
  { id: 7, name: "Loki Noir Perfume",  category: "Grooming",    price: 2499, originalPrice: 2999, badge: "BESTSELLER", emoji: "🌿", glow: "#0a2a18" },
  { id: 8, name: "Viking Beard Kit",   category: "Grooming",    price: 899,  originalPrice: 1199, badge: "BUNDLE",    emoji: "✂️", glow: "#1a200a" },
];

const CATEGORIES = ["All", "Clothing", "Footwear", "Accessories", "Grooming"];

/* ============================================================
   LANDING
============================================================ */
export default function Landing() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeCat, setActiveCat] = useState("All");
  const [cart, setCart] = useState([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [wishlist, setWishlist] = useState([]);
  const [addedId, setAddedId] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [heroIn, setHeroIn] = useState(false);

  const userName =
    location.state?.userName ||
    JSON.parse(localStorage.getItem("lokiLoggedIn") || "null")?.name ||
    JSON.parse(sessionStorage.getItem("lokiLoggedIn") || "null")?.name || null;

  useEffect(() => {
    const s = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", s);
    setTimeout(() => setHeroIn(true), 80);
    return () => window.removeEventListener("scroll", s);
  }, []);

  const filtered = activeCat === "All" ? products : products.filter(p => p.category === activeCat);

  const addToCart = (p) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === p.id);
      return ex ? prev.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i) : [...prev, { ...p, qty: 1 }];
    });
    setAddedId(p.id);
    setTimeout(() => setAddedId(null), 1200);
  };

  const removeItem = id => setCart(prev => prev.filter(i => i.id !== id));
  const toggleWish = id => setWishlist(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  const logout = () => {
    localStorage.removeItem("lokiLoggedIn");
    sessionStorage.removeItem("lokiLoggedIn");
    navigate("/login");
  };

  return (
    <div className="land-root">
      {/* Cursor */}
      <MagneticCursor />

      {/* Anti-Gravity Rune Field */}
      <GravityField count={34} repelRadius={155} repelForce={0.52} />

      {/* Deep BG layers */}
      <div className="land-bg">
        <div className="bg-base" />
        <div className="bg-grid" />
        <div className="bg-r1" /><div className="bg-r2" /><div className="bg-r3" />
        <div className="bg-noise" />
        <div className="bg-vignette" />
      </div>

      {/* ─── NAVBAR ─── */}
      <nav className={`nav ${scrolled ? "nav-solid" : ""}`}>
        <div className="nav-wrap">

          <div className="nav-logo">
            <div className="nav-logo-mark">
              <span className="nlm-rune">ᛚ</span>
              <div className="nlm-orbit" />
            </div>
            <div className="nav-logo-words">
              <span className="nlw-main">LOKI</span>
              <span className="nlw-sub">STORES</span>
            </div>
          </div>

          <div className={`nav-menu ${menuOpen ? "nav-menu-open" : ""}`}>
            {["Home","Collections","About","Contact"].map((item,i) => (
              <a key={item} href={`#${item.toLowerCase()}`} className="nm-link"
                style={{animationDelay:`${i*0.07}s`}} onClick={() => setMenuOpen(false)}>
                {item}<span className="nm-line" />
              </a>
            ))}
          </div>

          <div className="nav-right">
            {userName && (
              <div className="nav-user">
                <div className="nu-avatar">{userName[0].toUpperCase()}</div>
                <span className="nu-label">Hail, <b>{userName}</b></span>
              </div>
            )}
            <button className="nav-icon-btn" onClick={() => setDrawerOpen(true)} title="Cart">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/>
                <path d="M16 10a4 4 0 01-8 0"/>
              </svg>
              {cartCount > 0 && <span className="nib-badge">{cartCount}</span>}
            </button>
            {userName
              ? <button className="nav-btn nav-btn-ghost" onClick={logout}>Logout</button>
              : <button className="nav-btn" onClick={() => navigate("/login")}>Sign In</button>
            }
            <button className={`hamburger ${menuOpen ? "ham-active" : ""}`} onClick={() => setMenuOpen(!menuOpen)}>
              <span/><span/><span/>
            </button>
          </div>

        </div>
      </nav>

      {/* ─── HERO ─── */}
      <section id="home" className={`hero ${heroIn ? "hero-in" : ""}`}>
        <div className="hero-left">
          <div className="hero-eyebrow">
            <span className="he-rune">ᚷ</span>
            <span className="he-bar" />
            <span className="he-text">New Collection 2024</span>
            <span className="he-bar" />
            <span className="he-rune">ᚷ</span>
          </div>

          <h1 className="hero-h1">
            <span className="hh-line1">Dress Like</span>
            <span className="hh-line2">
              <Typewriter words={["A God.", "A King.", "A Legend.", "A Warrior."]} />
            </span>
          </h1>

          <p className="hero-p">
            Premium men's fashion forged from Norse mythology.<br />
            <em>Where strength becomes style.</em>
          </p>

          <div className="hero-btns">
            <button className="hbtn-primary"
              onClick={() => document.getElementById("collections")?.scrollIntoView({ behavior:"smooth" })}>
              <span>Explore Collection</span>
              <span className="hbtn-arrow">→</span>
              <div className="hbtn-shimmer" />
            </button>
            <button className="hbtn-ghost">
              <span className="hbtn-play">▶</span>Watch Lookbook
            </button>
          </div>

          <div className="hero-stats">
            {[
              { n: 12000, s: "+", l: "Happy Kings" },
              { n: 500,   s: "+", l: "Products" },
              { raw: "4.9★", l: "Avg Rating" },
            ].map((stat, i) => (
              <div key={i} className="hs-item">
                <div className="hs-num">
                  {stat.raw ? stat.raw : <CountUp end={stat.n} suffix={stat.s} />}
                </div>
                <div className="hs-label">{stat.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Hero visual — orbiting orb */}
        <div className="hero-right">
          <div className="hero-orb-wrap">
            <div className="orb-ring r1" /><div className="orb-ring r2" /><div className="orb-ring r3" />
            <div className="orb-core"><span className="orb-glyph">ᛚ</span></div>
            {[{ emoji:"🧥", label:"Jackets",  a: 0   },
              { emoji:"👟", label:"Sneakers", a: 120 },
              { emoji:"⌚", label:"Watches",  a: 240 }].map((item, i) => (
              <div key={i} className="orb-satellite" style={{"--sa": `${item.a}deg`}}>
                <span className="os-emoji">{item.emoji}</span>
                <span className="os-label">{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="hero-scroll">
          <div className="scroll-mouse"><div className="scroll-ball" /></div>
          <span>Scroll</span>
        </div>
      </section>

      {/* ─── MARQUEE ─── */}
      <div className="marquee-wrap">
        <div className="marquee-track">
          {Array(3).fill([
            { t:"FREE SHIPPING ABOVE ₹999", r:false },
            { t:"ᛚ", r:true },
            { t:"PREMIUM NORSE QUALITY", r:false },
            { t:"ᛟ", r:true },
            { t:"EASY 30-DAY RETURNS", r:false },
            { t:"ᚲ", r:true },
            { t:"EXCLUSIVE MEMBER DEALS", r:false },
            { t:"ᚷ", r:true },
            { t:"NEW DROPS EVERY WEEK", r:false },
            { t:"ᚨ", r:true },
          ]).flat().map((item, i) => (
            <span key={i} className={item.r ? "mq-r" : "mq-t"}>{item.t}</span>
          ))}
        </div>
      </div>

      {/* ─── FEATURE STRIP ─── */}
      <section className="feature-strip">
        <div className="fs-inner">
          {[
            { icon:"🛡", h:"Premium Quality",    d:"Every piece made to last generations" },
            { icon:"⚡", h:"Fast Delivery",       d:"Ships across India in 2–4 days" },
            { icon:"↩", h:"Easy Returns",         d:"30-day no-questions policy" },
            { icon:"🔒", h:"Secure Payments",    d:"100% encrypted checkout" },
          ].map((f, i) => (
            <Reveal key={i} delay={i * 90} from="bottom">
              <div className="fs-card">
                <span className="fs-icon">{f.icon}</span>
                <div className="fs-text">
                  <div className="fs-h">{f.h}</div>
                  <div className="fs-d">{f.d}</div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ─── COLLECTIONS ─── */}
      <section id="collections" className="collections">
        <Reveal from="bottom">
          <div className="sec-head">
            <div className="sec-eyebrow"><span className="sec-rune">ᛏ</span> Collections</div>
            <h2 className="sec-title"><GlitchTitle text="Forge Your Style" /></h2>
            <p className="sec-sub">Each piece crafted for the modern warrior</p>
          </div>
        </Reveal>

        <div className="cat-bar">
          {CATEGORIES.map(cat => (
            <button key={cat} className={`cat-btn ${activeCat === cat ? "cat-on" : ""}`}
              onClick={() => setActiveCat(cat)}>
              {cat}
              {activeCat === cat && <span className="cat-pill-glow" />}
            </button>
          ))}
        </div>

        <div className="prod-grid">
          {filtered.map((p, i) => (
            <div key={p.id} className="prod-card" style={{ animationDelay:`${i * 0.06}s` }}>
              <div className="pc-visual" style={{ background:`radial-gradient(circle at 38% 38%, ${p.glow}, #040504 72%)` }}>
                <div className="pc-glow-ring" />
                <span className="pc-emoji">{p.emoji}</span>
                <span className={`pc-badge pcb-${p.badge.toLowerCase()}`}>{p.badge}</span>
                <button className={`pc-wish ${wishlist.includes(p.id) ? "wished" : ""}`}
                  onClick={() => toggleWish(p.id)}>
                  {wishlist.includes(p.id) ? "♥" : "♡"}
                </button>
              </div>
              <div className="pc-body">
                <span className="pc-cat">{p.category}</span>
                <h3 className="pc-name">{p.name}</h3>
                <div className="pc-prices">
                  <span className="pc-now">₹{p.price.toLocaleString()}</span>
                  <span className="pc-was">₹{p.originalPrice.toLocaleString()}</span>
                  <span className="pc-pct">{Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100)}% OFF</span>
                </div>
                <button className={`pc-cart ${addedId === p.id ? "pc-added" : ""}`} onClick={() => addToCart(p)}>
                  <span>{addedId === p.id ? "✓ Added!" : "Add to Cart"}</span>
                  <div className="pc-cart-bg" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── PROMO ─── */}
      <section className="promo-section">
        <Reveal from="bottom">
          <div className="promo-card">
            <div className="promo-bg-glyph">ᚷ</div>
            <div className="promo-body-text">
              <span className="promo-tag">⚡ LIMITED OFFER</span>
              <h2 className="promo-h">Get 30% Off Your First Order</h2>
              <p className="promo-p">Use code <span className="promo-code">LOKI30</span> — valid for first-time customers.</p>
            </div>
            <button className="promo-btn">
              Claim Offer →
              <div className="promo-shimmer" />
            </button>
          </div>
        </Reveal>
      </section>

      {/* ─── TESTIMONIALS ─── */}
      <section className="testimonials">
        <Reveal from="bottom">
          <div className="sec-head">
            <div className="sec-eyebrow"><span className="sec-rune">ᛊ</span> Reviews</div>
            <h2 className="sec-title">Kings Have Spoken</h2>
          </div>
        </Reveal>
        <div className="test-grid">
          {[
            { name:"Arjun S.",  city:"Mumbai",    a:"A", text:"The Norse King Jacket is an absolute head-turner. Premium quality and delivery was blazing fast.", stars:5 },
            { name:"Rahul M.",  city:"Delhi",     a:"R", text:"Best men's brand I've discovered. The Loki Noir perfume has everyone asking what I'm wearing!", stars:5 },
            { name:"Vikram P.", city:"Bangalore", a:"V", text:"Premium feel at a fair price. The unboxing experience feels like opening a gift from Valhalla.", stars:5 },
          ].map((t, i) => (
            <Reveal key={i} delay={i * 110} from="bottom">
              <div className="test-card">
                <div className="tc-stars">{"★".repeat(t.stars)}</div>
                <p className="tc-text">"{t.text}"</p>
                <div className="tc-author">
                  <div className="tc-avatar">{t.a}</div>
                  <div>
                    <div className="tc-name">{t.name}</div>
                    <div className="tc-city">{t.city}</div>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ─── NEWSLETTER ─── */}
      <section className="newsletter">
        <Reveal from="bottom">
          <div className="nl-wrap">
            <div className="nl-runes">
              {["ᛟ","ᚱ","ᛞ"].map((r,i) => <span key={i} className="nl-r" style={{animationDelay:`${i*0.45}s`}}>{r}</span>)}
            </div>
            <h2 className="nl-h">Join the Brotherhood</h2>
            <p className="nl-p">Exclusive deals, early access & drops — direct to your realm.</p>
            <div className="nl-form">
              <input type="email" placeholder="your@email.com" className="nl-input" />
              <button className="nl-btn">
                Enter the Realm
                <div className="nl-shimmer" />
              </button>
            </div>
            <p className="nl-fine">No spam. Unsubscribe anytime. By the gods, we promise.</p>
          </div>
        </Reveal>
      </section>

      {/* ─── FOOTER ─── */}
      <footer className="footer">
        <div className="footer-inner">
          <div className="footer-brand">
            <div className="fb-logo">
              <span className="fb-rune">ᛚ</span>
              <div>
                <div className="fb-name">LOKI STORES</div>
                <div className="fb-tag">Dress Like a God</div>
              </div>
            </div>
            <p className="fb-about">Premium men's fashion inspired by Norse mythology. Crafted for the modern warrior.</p>
            <div className="fb-socials">
              {[["I","Instagram"],["T","Twitter"],["P","Pinterest"],["Y","YouTube"]].map(([l,n]) => (
                <a key={n} href="#" className="fb-soc" title={n}>{l}</a>
              ))}
            </div>
          </div>
          <div className="footer-cols">
            {[
              { h:"Shop",    ls:["New Arrivals","Clothing","Footwear","Accessories","Grooming"] },
              { h:"Support", ls:["FAQ","Shipping Policy","Returns","Track Order","Contact"] },
              { h:"Company", ls:["About Us","Careers","Press","Blog","Affiliate"] },
            ].map(col => (
              <div key={col.h} className="fc-col">
                <div className="fc-h">{col.h}</div>
                {col.ls.map(l => <a key={l} href="#" className="fc-link">{l}</a>)}
              </div>
            ))}
          </div>
        </div>
        <div className="footer-bar">
          <span>© 2024 Loki Stores. All rights reserved.</span>
          <div className="footer-rune-row">
            {["ᚠ","ᚢ","ᚦ","ᚨ","ᚱ"].map((r,i) => (
              <span key={i} className="fr-r" style={{animationDelay:`${i*0.28}s`}}>{r}</span>
            ))}
          </div>
          <span>Made with ♥ for the modern king</span>
        </div>
      </footer>

      {/* ─── CART DRAWER ─── */}
      <div className={`drawer-overlay ${drawerOpen ? "dov-on" : ""}`} onClick={() => setDrawerOpen(false)} />
      <div className={`cart-drawer ${drawerOpen ? "cd-open" : ""}`}>
        <div className="cd-head">
          <div className="cd-title"><span className="cd-rune">ᛟ</span>Your Cart</div>
          <button className="cd-close" onClick={() => setDrawerOpen(false)}>✕</button>
        </div>
        <div className="cd-body">
          {cart.length === 0 ? (
            <div className="cd-empty">
              <span className="cde-rune">ᚺ</span>
              <p>Your cart roams empty, warrior.</p>
              <button className="cde-btn" onClick={() => setDrawerOpen(false)}>Begin Thy Quest</button>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="cd-item">
                <div className="cdi-thumb">{item.emoji}</div>
                <div className="cdi-info">
                  <div className="cdi-name">{item.name}</div>
                  <div className="cdi-price">₹{(item.price * item.qty).toLocaleString()}</div>
                  <div className="cdi-qty">Qty: {item.qty}</div>
                </div>
                <button className="cdi-rm" onClick={() => removeItem(item.id)}>✕</button>
              </div>
            ))
          )}
        </div>
        {cart.length > 0 && (
          <div className="cd-foot">
            <div className="cdf-row">
              <span>Subtotal</span>
              <span className="cdf-total">₹{cartTotal.toLocaleString()}</span>
            </div>
            <p className="cdf-note">✓ Free shipping on this order</p>
            <button className="cdf-checkout">
              Proceed to Checkout →
              <div className="cdf-shimmer" />
            </button>
          </div>
        )}
      </div>

    </div>
  );
}
